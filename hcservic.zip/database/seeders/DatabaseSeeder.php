<?php

namespace Database\Seeders;

use App\Models\User;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        User::create([
            'nombre' => 'Administrador',
            'email' => 'admin@admin.com',
            'rol' => 'Gerente', // puedes cambiarlo si quieres otro rol
            'activo' => true,
            'password' => Hash::make('admin123'), // contraseña cifrada
        ]);
    }
}
