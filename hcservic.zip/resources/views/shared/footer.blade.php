<footer class="main-footer" style=" color: #151414;">
    <div class="footer-left">
        Copyright &copy; 2025 <div class="bullet"></div> Design By <a>Software Production</a>
    </div>
    <div class="footer-right">

    </div>
</footer>
