@php
use Illuminate\Support\Str;
@endphp
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>PRO-FORMA N°: {{ $recepcion->numero_recepcion ?? 'N/A' }}</title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 12px; color: #151414; }
        .header { text-align: center; margin-bottom: 10px; }
        .empresa-info { text-align: right; font-size: 11px; }
        .clearfix { clear: both; }
        .section { margin-bottom: 10px; }
        .datos-empresa, .datos-cliente, .tabla-equipos, .tabla-repuestos { width: 100%; border-collapse: collapse; margin-bottom: 10px; }
        .datos-empresa td, .datos-cliente td, .tabla-equipos th, .tabla-equipos td, .tabla-repuestos th, .tabla-repuestos td { font-size: 12px; padding: 3px; border: 1px solid #b0b0b0; }
        .titulo { font-weight: bold; padding: 4px; background: #000d53; color: #fff; text-align: center; }
        .fotos img { width: 180px; height: auto; margin-right: 5px; margin-bottom: 5px; display: inline-block; }
        .totales { width: 250px; margin-top: 10px; float: right; }
        .totales td { padding: 3px 6px; font-size: 12px; }
        .footer { font-size: 10px; text-align: center; margin-top: 20px; }
        .condiciones { font-size: 10px; margin-top: 15px; }
    </style>
</head>
<body>

<div class="header">
    <table width="100%">
        <tr>
            <td width="30%">
                <img src="{{ public_path('logo.jpeg') }}" alt="logo" width="100">
            </td>
            <td width="70%" class="empresa-info">
                <strong>HC INDUSTRIAL</strong><br>
                MANTENIMIENTO Y REPARACIÓN DE MAQUINARIA ELÉCTRICA INDUSTRIAL<br>
                Dir: 4to Anillo entre Av. Alemana y Av. Costanera<br>
                Cel: 76578154 - 72868051<br>
                <strong>PRO-FORMA</strong><br>
                <!-- Mostrar la fecha correctamente -->
                <strong>Fecha:</strong> {{ $fecha ?? 'N/A' }}
            </td>
        </tr>
    </table>
</div>
<div class="clearfix"></div>

<h3>PRO-FORMA N°: {{ $cod_cotizar ?? 'N/A' }}</h3>

<!-- Datos del cliente -->
<table class="datos-empresa">
    <tr>
        <td class="titulo" colspan="4">DATOS DEL CLIENTE</td>
    </tr>
    <tr>
        <td><strong>Tipo de cliente:</strong> {{ $cliente->tipo ?? 'Particular' }}</td>
        <td><strong>Solicitante:</strong> {{ $cliente->nombre ?? 'N/A' }}</td>
        <td><strong>N° Documento:</strong> {{ $cliente->numero_documento ?? 'N/A' }}</td>
        <td></td>
    </tr>
    <tr>
        <td><strong>Articulo:</strong> {{ optional($cotizacion->equipos->first()->equipo)->nombre ?? 'N/A' }}</td>
        <td><strong>Celular:</strong> {{ implode(' / ', array_filter([$cliente->telefono_1, $cliente->telefono_2, $cliente->telefono_3])) }}</td>
        <td colspan="2"></td>
    </tr>
</table>

<!-- Equipos, repuestos y fotos -->
@foreach($cotizacion->equipos as $cotizacionEquipo)
    @php
        $equipo = $cotizacionEquipo->equipo;
        $fotosSeleccionadas = $cotizacionEquipo->fotos ?? collect();
        $repuestos = $cotizacionEquipo->repuestos ?? collect();
        $servicios = $cotizacionEquipo->servicios ?? collect();
    @endphp

    <table class="tabla-equipos">
        <tr>
            <th colspan="5">DETALLES DEL EQUIPO: {{ $equipo ? Str::upper($equipo->nombre) : 'N/A' }}</th>
        </tr>
        <tr>
            <td><strong>Categoria:</strong> {{ $equipo ? Str::title(str_replace('_',' ', $equipo->tipo)) : 'N/A' }}</td>
            <td><strong>Marca:</strong> {{ $equipo->marca ?? 'N/A' }}</td>
            <td><strong>Modelo:</strong> {{ $equipo->modelo ?? 'N/A' }}</td>
            <td><strong>Color:</strong> {{ $equipo->color ?? 'N/A' }}</td>
            <td>-</td>
        </tr>
        <tr>
            <td colspan="5"><strong>Descripción del trabajo:</strong> {{ $cotizacionEquipo->trabajo_realizar ?? 'N/A' }}</td>
        </tr>
        <tr>
            <td colspan="2"><strong>Precio del trabajo:</strong> Bs. {{ number_format($cotizacionEquipo->precio_trabajo ?? 0, 2) }}</td>
            <td colspan="3"><strong>Total repuestos:</strong> Bs. {{ number_format($cotizacionEquipo->total_repuestos ?? 0, 2) }}</td>
        </tr>
    </table>

    <table class="tabla-repuestos">
        <tr>
            <th>DESCRIPCIÓN DE LOS REPUESTOS</th>
            <th>CANT</th>
            <th>U. UNITARIO</th>
            <th>TOTAL</th>
        </tr>
        @forelse($repuestos as $repuesto)
            <tr>
                <td>{{ $repuesto->nombre }}</td>
                <td>{{ $repuesto->cantidad ?? 0 }}</td>
                <td>Bs. {{ number_format($repuesto->precio_unitario ?? 0, 2) }}</td>
                <td>Bs. {{ number_format(($repuesto->cantidad ?? 0) * ($repuesto->precio_unitario ?? 0), 2) }}</td>
            </tr>
        @empty
            <tr>
                <td colspan="4" style="text-align: center;">No se especificaron repuestos</td>
            </tr>
        @endforelse
        <tr>
            <td colspan="4"><strong>IMÁGENES {{ $equipo ? Str::upper($equipo->nombre) : '' }}</strong></td>
        </tr>
        <tr>
            <td colspan="4">
                <div class="fotos">
                    @forelse($fotosSeleccionadas as $foto)
                        <img src="{{ public_path($foto->ruta) }}" alt="Foto del equipo">
                    @empty
                        <span style="color:#666;">Sin fotos seleccionadas</span>
                    @endforelse
                </div>
            </td>
        </tr>
    </table>

    <table class="tabla-repuestos">
        <tr>
            <th colspan="4">SERVICIOS REALIZADOS</th>
        </tr>
        @forelse($servicios as $i => $servicio)
            <tr>
                <td colspan="4">{{ $i+1 }}.- {{ $servicio->nombre }}</td>
            </tr>
        @empty
            <tr>
                <td colspan="4">No se especificaron servicios</td>
            </tr>
        @endforelse
    </table>
@endforeach

<!-- Totales -->
<table class="totales">
    <tr>
        <td>Sub Total Bs</td>
        <td>Bs. {{ number_format($subtotal ?? 0, 2) }}</td>
    </tr>
    <tr>
        <td>Descuento Bs</td>
        <td>Bs. {{ number_format($descuento ?? 0, 2) }}</td>
    </tr>
    <tr>
        <td><strong>Total Bs</strong></td>
        <td><strong>Bs. {{ number_format($total ?? 0, 2) }}</strong></td>
    </tr>
</table>

<div class="clearfix"></div>

<div class="condiciones">
    <strong>Esta cotización está sujeta a los términos y condiciones que se enuncian a continuación:</strong><br>
    1. Tiempo de entrega 2 a 3 días hábiles<br>
    2. Vigencia de la oferta 15 días hábiles<br>
    3. Forma de pago 50% por adelantado y saldo contra entrega<br>
    4. Garantía del servicio 3 meses<br>
    5. Taller HC no se responsabiliza por el equipo dejado más de 90 días<br>
    <br>
    Agradecemos su preferencia y quedamos a su disposición para cualquier consulta adicional.
</div>

<div class="footer">
    HC INDUSTRIAL - Mantenimiento y Reparación de Maquinaria Eléctrica Industrial
</div>

</body>
</html>
