<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Recepción {{ $recepcion->numero_recepcion }}</title>
    <style>
        body {
            font-family: DejaVu Sans, sans-serif;
            font-size: 10px;
            line-height: 1.2;
            color: #333;
        }

        /* Encabezado */
        .header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 2px;
        }

        .header-left img {
            width: 100px;
            height: auto;
        }

        .empresa-info {
            text-align: right;
            font-size: 10px;
            line-height: 1.3;
            color: #2c3e50;
             color: #000000;
            font-weight: bold; 
        }

        .header .title {
            flex: 1;
            text-align: center;
        }

        .header h1,
        .header h2 {
            margin-top: 0%; 
            margin: 0;
            color: #2c3e50;
        }

        /* Secciones */
        .section-title {
            background-color: #2574a8;
            color: #fff;
            padding: 4px 8px;
            border-radius: 1px;
            margin-top: 2px;
            margin-bottom: 5px;
            font-size: 12px;
        }

        /* Tablas */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 2px;
            page-break-inside: auto;
        }

        th,
        td {
            border: 1px solid #ffffff;
            padding: 4px 6px;
            text-align: left;
            vertical-align: top;
        }

        th {
            background-color: #ecf0f1;
            font-weight: bold;
        }

        tbody tr:nth-child(odd) {
            background-color: #ffffff;
        }

        tbody tr:nth-child(even) {
            background-color: #ffffff;
        }

        /* Sección de firmas */
        .signatures {
            width: 100%;
            text-align: center;
            margin-top: 20px;
            border: none;
            border-collapse: collapse;
            background-color: transparent;
        }

        .signatures td {
            border: none;
            text-align: center;
            width: 33%;
            padding-top: 40px;
            background-color: transparent;
        }

        .signature-line {
            border-top: 1px solid #000;
            width: 50%;
            margin: 0 auto 5px auto;
        }

        .signature-label {
            font-size: 10px;
            font-weight: bold;
            color: #2c3e50;
        }

        /* Bloques compactos */
        .inline-section {
            display: inline-block;
            width: 33%;
            vertical-align: top;
        }

        /* Pie de página */
        .footer {
            text-align: center;
            margin-top: 20px;
            font-size: 9px;
            color: #888;
        }
        .imp {
            margin-top: 0%;
            margin: 0;
            color: #000000;
            font-weight: bold;  
        }
    </style>
</head>

<body>
    <div class="header">
        <table width="100%">
            <tr>
                <td width="30%">
                    <img src="{{ public_path('logo.jpeg') }}" alt="logo" width="160">
                </td>
                <td>
                    <div class="title" style="text-align:center; margin-bottom:15px;"><br>
                        <h1>Recepción de Equipos</h1>
                        <h2>N° {{ $recepcion->numero_recepcion }}</h2>
                    </div>
                </td>
                <td width="40%" class="empresa-info" style="text-align:center;">
                    MANTENIMIENTO Y REPARACIÓN DE MOTORES ELÉCTRICOS Y MAQUINAS INDUSTRIALES<br>
                    Dir: 4to anillo entre Av. Alemana y Av. Mutualista esquina calle 
                    combate rio siño frente Av. 2 de Agosto<br>
                    Propietario: 75678184<br>
                    Encargado: 69176840 <br>
                    Oficina: 78459101 
                    <!-- Mostrar la fecha correctamente -->
                </td>
            </tr>
        </table>
    </div>
    <div class="clearfix"></div>



    <!-- Datos del Cliente y Recepción -->
    <div class="inline-section">
        <div class="section-title">Datos del Cliente</div>
        <table>
            <tr>
                <th>{{ $recepcion->cliente->tipo }}</th>
            </tr>
            <tr>
                <th>Nombre:</th>
                <td>{{ $recepcion->cliente->nombre }}</td>
            </tr>
            <tr>
                <th>{{ $recepcion->cliente->tipo_documento }}:</th>
                <td>{{ $recepcion->cliente->numero_documento }}</td>
            </tr>
            <tr>
                <th>Telefono:</th>
                <td>{{ $recepcion->cliente->telefono_1 ?? 'N/A' }} - {{ $recepcion->cliente->telefono_2 }}</td>
            </tr>
        </table>
    </div>

    <div class="inline-section">
        <div class="section-title">Datos de Recepción</div>
        <table>
            <tr>
                <th>Recepcionista: </th>
                <td>{{ optional($recepcion->usuario)->nombre ?? 'N/A' }}</td>
            </tr>
            <tr>
                <th>Fecha:</th>
                <td>{{ \Carbon\Carbon::parse($recepcion->fecha_ingreso)->format('d/m/Y') }}
            </tr>
            <tr>
                <th>Hora:</th>
                <td>
                    {{ \Carbon\Carbon::parse($recepcion->hora_ingreso)->format('H:i') }}
                </td>
            </tr>
            <tr>
                <th>Tipo de servicio:</th>
                <td>{{ $recepcion->tipo_recepcion ?? 'N/A'  }}</td>
            </tr>
        </table>
    </div>
    <div class="inline-section">
        <div class="section-title">Fotos de equipos</div>
        <table>
            @foreach ($recepcion->equipos as $index => $equipo)
                @if ($equipo->fotos->count() > 0)
                    <tr>
                        <td>
                            <div style=" text-align:center;">
                                @php
                                    $foto = $equipo->fotos->first();
                                @endphp
                                <img src="{{ public_path($foto->ruta) }}" alt="Foto del equipo"
                                    style="max-width: 160px; max-height: 140px; height: auto; width: auto;">
                            </div>
                        </td>
                    </tr>
                @endif
            @endforeach
        </table>
    </div>
        <div class="imp">
        Importante: {{  $importante->importante ?? '' }}   
    </div>
    <!-- Equipos Recepcionados -->
    <div class="section-title">Equipos Recepcionados</div>
    <table style="font-size: 8px;">
        <thead>
            <tr>
                <th>#</th>
                <th>Artículo</th>
                <th>Marca</th>
                <th>Modelo</th>
                <th>Tipo</th>
                <th>Color(es)</th>
                <th>Monto</th>
                <th>Voltaje</th>
                <th>HP</th>
                <th>RPM</th>
                <th>Hz</th>
                <th>AMP</th>
                <th>Cable +</th>
                <th>Cable -</th>
                <th>KVA/<br>KW</th>
                <th>Potencia</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($recepcion->equipos as $index => $equipo)
                <tr>
                    <td>{{ $index + 1 }}</td>
                    <td>{{ $equipo->nombre }}</td>
                    <td>{{ $equipo->marca }}</td>
                    <td>{{ $equipo->modelo ?? '-' }}</td>
                    <td>{{ $equipo->tipo }}</td>
                    <td>{{ $equipo->color ?? '-' }}</td>
                    <td>Bs. {{ number_format($equipo->monto, 2) }}</td>
                    <td>{{ $equipo->voltaje ?? '-' }}</td>
                    <td>{{ $equipo->hp ?? '-' }}</td>
                    <td>{{ $equipo->rpm ?? '-' }}</td>
                    <td>{{ $equipo->hz ?? '-' }}</td>
                    <td>{{ $equipo->amperaje ?? '-' }}</td>
                    <td>{{ $equipo->cable_positivo ?? '-' }}</td>
                    <td>{{ $equipo->cable_negativo ?? '-' }}</td>
                    <td>{{ $equipo->kva_kw ?? '-' }}</td>
                    <td>{{ $equipo->potencia ? $equipo->potencia . ' ' . ($equipo->potencia_unidad ?? '') : '-' }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
    <!-- Firmas -->
<table class="signatures" style="width:100%; margin-top:40px; text-align:center;">
    <tr>
        <td style="width:50%;">
            <div style="border-top:1px solid #000; width:80%; margin:0 auto;"></div>
            <div style="margin-top:4px;">Firma HC</div>
        </td>
        <td style="width:50%;">
            <div style="border-top:1px solid #000; width:80%; margin:0 auto;"></div>
            <div style="margin-top:4px;">Firma Cliente</div>
        </td>
    </tr>
</table>

<!-- Pie IMPORTANTE fuera de la tabla -->
<div style="font-size:9px; margin-top:0px; text-align:justify; line-height:1.2;" class="footer">
    IMPORTANTE: La presente maquinaria deberá ser retirada en el término de 90 días. A partir de la fecha,
    pasado dicho tiempo la obligación será considerada de plazo vencido y exigible por el monto líquido,
    que arroja valor en mano de obra, materiales y repuestos. BOBINADO INDUSTRIAL HC se reserva con el
    derecho de proceder con la venta directa del equipo dentro del plazo. En conformidad con lo dispuesto
    por el artículo 812 del código civil de Bolivia.
</div>



</body>

</html>
